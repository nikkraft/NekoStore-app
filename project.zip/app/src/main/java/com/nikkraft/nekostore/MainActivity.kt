package com.nikkraft.nekostore

import android.Manifest
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private val siteHost = "nikkraft.github.io"
    private val siteUrl = "https://$siteHost"

    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private val installs = mutableMapOf<Long, String>()

    private val downloadDone = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            val name = installs.remove(id) ?: return
            installApk(File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        swipe = SwipeRefreshLayout(this).apply { addView(web) }
        setContentView(swipe)

        Notifier.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        scheduleUpdateCheck()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == siteHost) return false
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, r.url)) }
                return true
            }

            override fun onPageFinished(v: WebView, url: String) {
                swipe.isRefreshing = false
            }
        }
        web.setDownloadListener(DownloadListener { url, _, cd, mime, _ ->
            download(url, URLUtil.guessFileName(url, cd, mime), false)
        })

        // Потяни-вниз: обновить страницу, только когда она прокручена к самому верху
        swipe.setColorSchemeColors(0xFF6750A4.toInt())
        swipe.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        swipe.setOnRefreshListener { web.reload() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        ContextCompat.registerReceiver(
            this, downloadDone,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED
        )

        if (savedInstanceState == null) web.loadUrl(siteUrl) else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        unregisterReceiver(downloadDone)
        super.onDestroy()
    }

    /* ---------- Фоновая проверка обновлений ---------- */
    private fun scheduleUpdateCheck() {
        val req = PeriodicWorkRequestBuilder<UpdateWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("updates", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /* ---------- Мост JS -> Android ---------- */
    inner class Bridge {
        @JavascriptInterface
        fun notify(title: String, text: String) {
            Notifier.show(applicationContext, System.currentTimeMillis().toInt(), title, text)
        }

        /** Сайт сообщает, за каким репозиторием следить и включены ли уведомления. */
        @JavascriptInterface
        fun setWatch(repo: String, enabled: Boolean) {
            if (!Regex("^[\\w.-]+/[\\w.-]+$").matches(repo)) return
            getSharedPreferences("watch", MODE_PRIVATE).edit()
                .putString("repo", repo).putBoolean("enabled", enabled).apply()
        }

        @JavascriptInterface
        fun install(url: String, file: String) {
            if (!url.startsWith("https://github.com/")) return
            val safe = file.replace(Regex("[^\\w.\\- ]"), "_")
            runOnUiThread { download(url, safe, true) }
        }
    }

    /* ---------- Загрузка и установка ---------- */
    private fun download(url: String, name: String, install: Boolean) {
        if (install && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Разрешите установку из этого источника и нажмите «Скачать» ещё раз", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return
        }
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(name)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        if (install) {
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name).delete()
            req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
        } else {
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        }
        val id = getSystemService(DownloadManager::class.java).enqueue(req)
        if (install) installs[id] = name
        Toast.makeText(this, "Загрузка: $name", Toast.LENGTH_SHORT).show()
    }

    private fun installApk(file: File) {
        if (!file.exists()) {
            Toast.makeText(this, "Не удалось скачать файл", Toast.LENGTH_LONG).show()
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }
}
