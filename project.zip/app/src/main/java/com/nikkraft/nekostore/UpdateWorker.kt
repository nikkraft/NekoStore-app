package com.nikkraft.nekostore

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Фоновая проверка новых версий в Releases (работает и при закрытом приложении). */
class UpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private data class App(val name: String, val ver: String)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val sp = applicationContext.getSharedPreferences("watch", Context.MODE_PRIVATE)
        val repo = sp.getString("repo", null) ?: return@withContext Result.success()
        if (!sp.getBoolean("enabled", false)) return@withContext Result.success()

        val now = try {
            parse(fetch("https://api.github.com/repos/$repo/releases?per_page=50"))
        } catch (e: Exception) {
            return@withContext Result.retry()
        }

        val key = "seen:$repo"
        val seen = sp.getString(key, null)?.let { JSONObject(it) }
        if (seen != null) {
            for ((k, a) in now) {
                val old = seen.optString(k, "")
                when {
                    old.isEmpty() -> Notifier.show(applicationContext, k.hashCode(), "Новое в NekoStore", "${a.name} v${a.ver}")
                    cmp(a.ver, old) > 0 -> Notifier.show(applicationContext, k.hashCode(), "Доступно обновление", "${a.name} v${a.ver}")
                }
            }
        }
        val save = JSONObject()
        for ((k, a) in now) save.put(k, a.ver)
        sp.edit().putString(key, save.toString()).apply()
        Result.success()
    }

    private fun fetch(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private val skip = Regex("\\.(png|webp|jpe?g|sha\\d*|txt|md|sig|asc)$", RegexOption.IGNORE_CASE)
    private val nameRe = Regex("^(.+?)[-_ ]v?(\\d+(?:\\.\\d+)*)(?:[-_.][a-z0-9]+)*\\.(\\w+)$", RegexOption.IGNORE_CASE)

    /** Имя-vX.Y.Z.apk -> последняя версия по каждому имени (как на сайте). */
    private fun parse(json: String): Map<String, App> {
        val map = mutableMapOf<String, App>()
        val rel = JSONArray(json)
        for (i in 0 until rel.length()) {
            val r = rel.getJSONObject(i)
            if (r.optBoolean("draft")) continue
            val tag = r.optString("tag_name").removePrefix("v")
            val assets = r.getJSONArray("assets")
            for (j in 0 until assets.length()) {
                val file = assets.getJSONObject(j).getString("name")
                if (skip.containsMatchIn(file)) continue
                val m = nameRe.find(file)
                val name: String
                val ver: String
                if (m != null) {
                    name = m.groupValues[1].replace(Regex("[_-]+"), " ").trim()
                    ver = m.groupValues[2]
                } else {
                    name = file.substringBeforeLast('.').replace(Regex("[_-]+"), " ")
                    ver = tag.ifEmpty { "0" }
                }
                val k = name.lowercase()
                val cur = map[k]
                if (cur == null || cmp(ver, cur.ver) > 0) map[k] = App(name, ver)
            }
        }
        return map
    }

    private fun cmp(a: String, b: String): Int {
        val x = a.split('.', '-').map { it.toIntOrNull() ?: 0 }
        val y = b.split('.', '-').map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = x.getOrElse(i) { 0 } - y.getOrElse(i) { 0 }
            if (d != 0) return if (d > 0) 1 else -1
        }
        return 0
    }
}
