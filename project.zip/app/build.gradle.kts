import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Данные подписи: keystore.properties (локально) или переменные окружения (GitHub Actions)
val ksProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun sign(prop: String, env: String): String? = ksProps.getProperty(prop) ?: System.getenv(env)

android {
    namespace = "com.nikkraft.nekostore"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nikkraft.nekostore"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.1.0"
    }

    signingConfigs {
        create("release") {
            val path = sign("storeFile", "KEYSTORE_FILE")
            if (path != null) {
                storeFile = rootProject.file(path)
                storePassword = sign("storePassword", "KEYSTORE_PASSWORD")
                keyAlias = sign("keyAlias", "KEY_ALIAS")
                keyPassword = sign("keyPassword", "KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            val cfg = signingConfigs.getByName("release")
            if (cfg.storeFile != null) signingConfig = cfg
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
