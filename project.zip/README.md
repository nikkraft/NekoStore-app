# NekoStore (Android)

Оболочка над сайтом nikkraft.github.io. Пакет: `com.nikkraft.nekostore`.

## Подпись release-APK

1. Создай keystore один раз (Termux: `pkg install openjdk-17`):

       keytool -genkeypair -v -keystore nekostore.jks -alias nekostore \
         -keyalg RSA -keysize 2048 -validity 10000

   Либо в Android Studio: Build -> Generate Signed App Bundle / APK -> Create new.
   Храни `.jks` и пароли в надёжном месте: потеряешь — обновить приложение поверх не получится.

2. Локально: создай `keystore.properties` рядом с `settings.gradle.kts`:

       storeFile=nekostore.jks
       storePassword=...
       keyAlias=nekostore
       keyPassword=...

   Затем Build -> Build APK(s) с вариантом `release`.

3. GitHub Actions: в Settings -> Secrets and variables -> Actions добавь секреты

       KEYSTORE_BASE64    (вывод: base64 -w0 nekostore.jks)
       KEYSTORE_PASSWORD
       KEY_ALIAS
       KEY_PASSWORD

   Без секретов workflow соберёт debug-APK.

Нельзя заливать `.jks` и `keystore.properties` в репозиторий (они в .gitignore).
